# annotation-
Image annotation using DEXTR in CVAT
# label:color_rgb:parts:actions
Cabinate:140,120,240::
Lighting:255,204,51::
Mirror:178,80,80::
Showerheads:89,134,179::
background:0,0,0::
bathtub:52,209,183::
commode:250,50,183::
faucet:89,134,185::
sinks:51,221,255::



![image](https://user-images.githubusercontent.com/116526268/202929511-f4a80040-0bf5-49d5-b93e-b407a1b221b3.png)

![image](https://user-images.githubusercontent.com/116526268/202929863-82335276-9247-4b33-9de5-ad9ca6c98fac.png)

